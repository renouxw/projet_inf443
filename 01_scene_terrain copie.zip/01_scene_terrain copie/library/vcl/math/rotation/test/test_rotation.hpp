#pragma once

namespace vcl_test
{
	void test_rotation();
}