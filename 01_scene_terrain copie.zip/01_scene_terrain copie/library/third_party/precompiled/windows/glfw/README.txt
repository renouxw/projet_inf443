Precompiled library provided for Visual Studio 2019 (Windows 64 bits)

For other version of Visual Studio, download and replace with the corresponding library version
https://www.glfw.org/download.html

