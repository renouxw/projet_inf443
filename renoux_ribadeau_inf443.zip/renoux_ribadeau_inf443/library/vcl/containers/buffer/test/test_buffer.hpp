#pragma once


namespace vcl_test
{
	void text_buffer();
}

