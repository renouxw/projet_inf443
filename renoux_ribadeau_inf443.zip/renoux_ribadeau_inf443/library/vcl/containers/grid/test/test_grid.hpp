#pragma once

namespace vcl_test
{
	void text_grid_2D();
	void text_grid_3D();
}
