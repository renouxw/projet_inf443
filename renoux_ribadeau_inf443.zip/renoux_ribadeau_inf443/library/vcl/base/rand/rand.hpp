#pragma once

namespace vcl
{

float rand_interval(const float value_min=0.0f, const float value_max=1.0f);

}
