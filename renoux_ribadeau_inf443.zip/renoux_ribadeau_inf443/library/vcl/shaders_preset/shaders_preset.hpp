#pragma once

#include <string>

namespace vcl
{
	std::string opengl_shader_preset(std::string const& shader_name);
}