#pragma once

#include "structure/mesh.hpp"
#include "primitive/mesh_primitive.hpp"
#include "loader/loader.hpp"