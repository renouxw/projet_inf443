#pragma once

#include "vcl/vcl.hpp"

vcl::hierarchy_mesh_drawable create_birds();
